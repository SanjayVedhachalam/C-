using System;

namespace Assignment6
{
    public class IDBI:Bank
    {
        public override double GetIntresetInfo()
        {
            return 7.5;
        }
    }
}

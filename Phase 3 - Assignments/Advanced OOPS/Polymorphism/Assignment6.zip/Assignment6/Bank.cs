using System;

namespace Assignment6
{
    public abstract class Bank
    {
        public abstract double GetIntresetInfo();
    }
}

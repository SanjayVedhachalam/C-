using System;

namespace Assignment6
{
    public class ICICI:Bank
    {
        public override double GetIntresetInfo()
        {
            return 7.5;
        }
    }
}

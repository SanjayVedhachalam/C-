﻿using System;
using Assignment_1;
namespace Assignment1;
class Program
{
    public static void Main(string[] args)
    {
        Hack hack=new Hack("Password");
        hack.ShowKeyInfo();
    }
}
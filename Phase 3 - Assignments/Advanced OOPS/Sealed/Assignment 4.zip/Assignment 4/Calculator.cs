using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment_4
{
    public abstract class Calculator
    {
        public abstract void Area(double radius);
        public void Volume(){

        }
    }
}
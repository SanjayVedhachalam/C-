using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment_2
{
    public class DepartmentDetails
    {
        public string DepartmentName { get; set; }
        public string Degree { get; set; }
    }
}
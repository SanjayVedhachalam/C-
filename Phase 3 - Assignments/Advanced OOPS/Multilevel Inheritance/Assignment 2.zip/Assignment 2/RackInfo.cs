using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment_2
{
    public class RackInfo:DepartmentDetails
    {
        public int RackNumber { get; set; }
        public int ColumnNumber { get; set; }
    }
}